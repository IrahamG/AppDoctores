# Aplicación de doctores
Repositorio para la aplicación de doctores de la clase de Martín.
**No trabajar en la rama principal del repositorio**. Crear ramas distintas y consultar antes de combinarlas con la rama principal.

Enlace del Trello:
https://trello.com/invite/b/GcdkDoWN/be6537e3ca1f76837ccc1cd8ea5e626a/aplicacion-doctores
